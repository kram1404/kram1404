package utils;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

public class TestListener extends TestListenerAdapter {
   @Override
   public void onTestStart(ITestResult result){
       
   }
}